package Template;

public abstract class HouseTemplate {
	HouseTemplate(){

	}
	public void buildhouse(){
		
	}
	public void buildwindows(){
		System.out.println("Windows have been Built.");
	}
	public void buildfoundation(){
		System.out.println("Foundation has been Built.");
	}

}
