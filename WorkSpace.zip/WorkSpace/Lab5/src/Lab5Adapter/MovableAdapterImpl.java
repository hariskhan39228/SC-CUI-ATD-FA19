package Lab5Adapter;

public class MovableAdapterImpl implements MovableAdapter {
    private Movable luxuryCars;
 
    private double convertMPHtoKMPH(double mph) {
        return mph * 1.60934;
    }

	@Override
	public double getSpeed() {
		return convertMPHtoKMPH(luxuryCars.getSpeed());
	}
}
