package Lab5Adapter;

public interface Movable {
    public double getSpeed();
}