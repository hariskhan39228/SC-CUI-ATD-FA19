package Lab5Decorator;

public interface Shape {
	void draw();

}
