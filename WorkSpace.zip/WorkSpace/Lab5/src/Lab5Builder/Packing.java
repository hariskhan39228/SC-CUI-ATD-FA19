package Lab5Builder;

public interface Packing {
	public String Pack();
	public int Price();

}
