package Lab5Builder;

public class Sony extends Company{  
	
	@ Override public int Price(){   
		return 200;  
    }  
    @Override public String Pack(){  
    	return "Sony CD";  
    }
}
