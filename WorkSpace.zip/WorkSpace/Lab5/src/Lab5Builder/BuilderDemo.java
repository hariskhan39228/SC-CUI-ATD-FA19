package Lab5Builder;

public class BuilderDemo {
	public static void main(String args[]){  
		CDBuilder cdBuilder=new CDBuilder();  
		CDtype cdType1=cdBuilder.buildSonyCD();  
		cdType1.showItems();  
		  
		CDtype cdType2=cdBuilder.buildSamsungCD();  
		cdType2.showItems();  
		}  

}
