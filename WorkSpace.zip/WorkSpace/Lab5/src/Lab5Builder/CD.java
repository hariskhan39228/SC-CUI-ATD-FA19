package Lab5Builder;

public abstract class CD implements Packing{  
public abstract String Pack();  
}  