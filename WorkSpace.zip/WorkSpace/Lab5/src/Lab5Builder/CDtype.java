package Lab5Builder;

import java.util.ArrayList;
import java.util.*;

public class CDtype {  
    private List<Packing> items=new ArrayList<Packing>();  
    public void addItem(Packing packs) {    
    	items.add(packs);  
    }  
    public void getCost(){  
     for (Packing packs : items) {  
    	 packs.Price();  
     }   
    }  
    public void showItems(){  
    	for (Packing packing : items){  
    		System.out.print("CD name : "+packing.Pack());  
    		System.out.println(", Price : "+packing.Price());  
    		}        
    	}    
}
