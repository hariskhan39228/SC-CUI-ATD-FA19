/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab;

/**
 *
 * @author fa16-bse-173
 */
public class ShapeFactory {
    public Shape getshape(String Shapetype){
        if(Shapetype==null){
            return null;
        }
        if(Shapetype.equalsIgnoreCase("Circle")){
            return (new Circle());
        }else if(Shapetype.equalsIgnoreCase("Square")){
            return (new Square());
        }else if(Shapetype.equalsIgnoreCase("Rectangle")){
            return (new Rectangle());
        }
        return null;
    }
}
