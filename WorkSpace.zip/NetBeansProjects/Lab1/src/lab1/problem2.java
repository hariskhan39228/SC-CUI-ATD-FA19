/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;
import java.util.Scanner;
import java.util.*;
/**
 *
 * @author fa16-bse-173
 */
public class problem2 {
    public void work(){
        ////////////////////////////////////////////////////////////////// 
        int x=0;
        int y=1;
        int z=2;
        int l=0;
        ////////////////////////////////////////////////////////////////// 
        Scanner input =new Scanner(System.in);
        ////////////////////////////////////////////////////////////////// 
        System.out.print("Enter Series Limit: ");
        l=input.nextInt();
        ////////////////////////////////////////////////////////////////// 
        int [] f=new int [l];
        ////////////////////////////////////////////////////////////////// 
        for (int i = 0; i < f.length; i++) {
            int check=x+y;
            if(i==0||i==1){
                f[i]=1;
                x=f[i];y=f[i];
            }else{
                z=x+y;
                f[i]=z;
                x=f[i-1];
                y=f[i];
            }
        }
        ////////////////////////////////////////////////////////////////// 
        System.out.print("Fibnocci series: ");
        for (int i = 0; i < f.length; i++) {
            System.out.print(f[i]+" ");
        }
        //////////////////////////////////////////////////////////////////         
    }
}
