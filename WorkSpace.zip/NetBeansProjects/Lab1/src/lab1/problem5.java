/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;
import java.util.Scanner;
import java.util.*;
/**
 *
 * @author fa16-bse-173
 */
public class problem5 {
    public void work(){
        //////////////////////////////////////////////////////////////////
        int x;
        int y;
        //////////////////////////////////////////////////////////////////
        char c;
        //////////////////////////////////////////////////////////////////
        Scanner input =new Scanner(System.in);
        //////////////////////////////////////////////////////////////////
        System.out.print("Enter operator symbol, Operation etc (+,-,/,*): ");
        c=input.next().charAt(0);
        //////////////////////////////////////////////////////////////////
        System.out.print("Enter ist nuber: ");
        x=input.nextInt();
        System.out.print("Enter 2nd nuber: ");
        y=input.nextInt();
        //////////////////////////////////////////////////////////////////
        if(c=='+'){
            System.out.println(x+" + "+y+" : "+(x+y));
        }else if(c=='-'){
            System.out.println(x+" - "+y+" : "+(x-y));
        }else if(c=='*'){
            System.out.println(x+" * "+y+" : "+(x*y));
        }else if(c=='/'){
            System.out.println(x+" / "+y+" : "+(x/y));
        }
        //////////////////////////////////////////////////////////////////
    }
}
