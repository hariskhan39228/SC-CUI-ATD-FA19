/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;
import java.util.Scanner;
import java.util.*;
/**
 *
 * @author fa16-bse-173
 */
public class Data {
    static StringBuilder x=new StringBuilder();
    static StringBuilder y=new StringBuilder();
    static char operator;
    static int x1=0;
    static int y1=0;
    static int z=0;
            
    
}
