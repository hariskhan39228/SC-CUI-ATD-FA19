/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB;

import java.util.Scanner;

/**
 *
 * @author fa16-bse-173
 */
public abstract class Student {
    /////////////////////////////////////////////////////////
    protected final int test = 3;
    protected String name;
    protected String CourseGrade;
    protected int [] TestResults = new int [test];
    Scanner input=new Scanner(System.in);
    
    protected int marks;
    /////////////////////////////////////////////////////////
    public Student(){
        
    }
    /////////////////////////////////////////////////////////
    public Student(String name){
        this.name=name;
    }
    /////////////////////////////////////////////////////////
    public int getTest() {
        return test;
    }
    public String getName() {
        return name;
    }
    public int getTestResults(int testnumber) {
        return TestResults[testnumber-1];
    }
    /////////////////////////////////////////////////////////
    public void setName(String name) {
        this.name = name;
    }
    public void setCourseGrade(String CourseGrade) {
        this.CourseGrade = CourseGrade;
    }
    /////////////////////////////////////////////////////////
    public abstract String getCoursegrade();
    ///////////////////////////////////////////////////////// 
}
