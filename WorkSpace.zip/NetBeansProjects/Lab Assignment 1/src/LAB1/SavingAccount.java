/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB1;

/**
 *
 * @author fa16-bse-173
 */
public class SavingAccount {
    /////////////////////////////////////////////////////////////////
    private double accBalance=0.000;
    private double annIntrestrate=0.00;
    /////////////////////////////////////////////////////////////////
    public SavingAccount(double starting, double annintrest){
        accBalance=starting;
        annIntrestrate=annintrest;
    }
    /////////////////////////////////////////////////////////////////

    public double getAccBalance() {
        return accBalance;
    }

    public double getAnnIntrestrate() {
        return annIntrestrate;
    }

    public void setAccBalance(double accBalance) {
        this.accBalance = accBalance;
    }

    public void setAnnIntrestrate(double annIntrestrate) {
        this.annIntrestrate = annIntrestrate;
    }
    ////////////////////////////////////////////////////////////////
    public void Withdraw(double wamt){
        setAccBalance((accBalance-wamt));
    }
    ////////////////////////////////////////////////////////////////
    public void Deposit(double Damt){
        setAccBalance((accBalance+Damt));
    }
    ////////////////////////////////////////////////////////////////
    public double addmonthlyintrest(){
        double monthlyintrestrate=(getAnnIntrestrate()/1200.00);
        double monthlyintrest=(getAccBalance()*monthlyintrestrate);
        setAccBalance(accBalance+monthlyintrest);
        return monthlyintrest;
    }
    ////////////////////////////////////////////////////////////////
}
