/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB1;
import java.util.Scanner;
import java.util.*;
/**
 *
 * @author fa16-bse-173
 */
public class TestProgram {
    public static void main(String[] args) {
        //////////////////////////////////////////////
        Scanner input=new Scanner(System.in);
        double annintrest=0.00;
        double startbal=0.000;
        double noofmonths=0;
        //////////////////////////////////////////////
        while(annintrest<=0){
        System.out.print("Please Enter Annual Intrest Rate: ");
        annintrest=input.nextDouble();
        if(annintrest<=0){
            System.out.print("Please Enter a valid Annual Intrest Rate (greater then zero): ");
            annintrest=input.nextDouble();
        }
    }
        
        //////////////////////////////////////////////
        System.out.print("Please Enter Starting Balance: ");
        startbal=input.nextDouble();
        //////////////////////////////////////////////
        System.out.print("Please Enter no of months passed since oppening of account: ");
        noofmonths=input.nextDouble();
        //////////////////////////////////////////////
        SavingAccount s1=new SavingAccount(startbal,annintrest);
        //////////////////////////////////////////////
        double amtwithdrawn=0;
        double amtdeposited=0;
        for (int i = 0; i < noofmonths; i++) {
            System.out.print("Please Enter the amount withdrwan douring month "+(i+1)+" : ");
            amtwithdrawn=input.nextDouble();
            s1.Withdraw(amtwithdrawn);
            //////////////////////////////////////////////
            System.out.print("Please Enter the amount deposited douring month "+(i+1)+" : ");
            amtdeposited=input.nextDouble();
            s1.Deposit(amtdeposited);
            //////////////////////////////////////////////
            System.out.println("month "+(i+1)+"'s intrest is: "+s1.addmonthlyintrest());
            System.out.println("Total Ammount after addition of intrest: "+s1.getAccBalance());
            //////////////////////////////////////////////
        }
    }
}
